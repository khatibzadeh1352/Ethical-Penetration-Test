?package(loki):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="loki" command="/usr/bin/loki"
