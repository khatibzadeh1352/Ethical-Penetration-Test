# Defaults for loki initscript
# sourced by /etc/init.d/loki
# installed at /etc/default/loki by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
